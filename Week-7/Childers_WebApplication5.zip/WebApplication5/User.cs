﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace WebApplication5
{
    public class User
    {

        public DataSet getAllUsers()
        {
            //Call database here instead of on default page
            Database myDatabase = new Database();

            string query = "PaigeInsertUser";

            DataSet myDataSet = myDatabase.getData(query);
            return myDataSet; // function is finished once it hits this


        }

        public void PaigeInsertUser(string FirstName, string LastName, string UserEmail, string HiddenKey) //has to have 4 since it has 4 in the parameters
        {
            SqlConnection myConnection = openDatabase;
            myCommand.Connection = myConnection;
            string query = "PaigeInsertUser";
            SqlParameter[] sqlParameters = new SqlParameter[4]; //is this 4???
            sqlParameters[0] = new SqlParameter("firstname", FirstName);
            sqlParameters[1] = new SqlParameter("lastname", LastName);
            sqlParameters[2] = new SqlParameter("email", UserEmail);
            sqlParameters[3] = new SqlParameter("password", HiddenKey);

            //Put into get data in Database.cs
            //SqlCommand myCommand = new SqlCommand(query);
            //myCommand.Connection = myConnection;
            //myCommand.CommandType = CommandType.StoredProcedure;
            //myCommand.Parameters.AddRange(sqlParameter);

            myCommand.ExecuteNonQuery();
            myDatabase.closeDatabase(myConnection); //must remain open until after the query is done executing

        }

        public void PaigeUpdateUser(string FirstName, string LastName, string UserEmail, string HiddenKey, int userid)
        {
            Database myDatabase = new Database();


            //add parameter for password
            string query = "PaigeUpdateUser";
            SqlParameter[] sqlParameters = new SqlParameter[5];
            sqlParameters[0] = new SqlParameter("firstname", FirstName);
            sqlParameters[1] = new SqlParameter("lastname", LastName);
            sqlParameters[2] = new SqlParameter("email", UserEmail);
            sqlParameters[3] = new SqlParameter("userid", userid);
            sqlParameters[4] = new SqlParameter("password", HiddenKey); //can I title this password right here?

            myDatabase.executeNonQueryWithParameters(sqlParameters, query);

        }

        public void PaigeDeleteUser(string FirstName, string LastName, string UserEmail, string HiddenKey, int userid)
        {
            Database myDatabase = new Database();

            string query = "PaigeDeleteUser";
            SqlParameter[] sqlParameters = new SqlParameter[5];
            sqlParameters[0] = new SqlParameter("firstname", FirstName);
            sqlParameters[1] = new SqlParameter("lastname", LastName);
            sqlParameters[2] = new SqlParameter("email", UserEmail);
            sqlParameters[3] = new SqlParameter("userid", userid);
            sqlParameters[4] = new SqlParameter("password", HiddenKey); //can I title this password right here?

        }

        public void PaigeSelectAllUsers(string Firstname, string LastName, string UserEmail, string HiddenKey) //where do I need to add int userid and where don't I?
        {
            Database myDatabase = new Database();

            string query = "PaigeSelectAllUsers";
            SqlParameter[] sqlParameters = new SqlParameter[4]; //change to 5 if adding userid
            sqlParameters[0] = new SqlParameter("firstname", FirstName);
            sqlParameters[1] = new SqlParameter("lastname", LastName);
            sqlParameters[2] = new SqlParameter("email", UserEmail);
            //sqlParameters[3] = new SqlParameter("userid", userid);
            sqlParameters[3] = new SqlParameter("password", HiddenKey); //can I title this password right here?
        }
    }
}