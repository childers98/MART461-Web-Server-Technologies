﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication5
{
    public partial class admin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
            
           
            if(!Page.IsPostBack)
            {
                fillUsers();
            }
            else
            {
                
                /// this gets user id from dropdownlist
                int userid = Convert.ToInt32(ddlUsers.SelectedValue);
                // prevents insert from crashing first time
                if(userid > 0 && Session["userid"] == null)
                {
                    Session["userid"] = userid;
                  //  Response.Write(Convert.ToBoolean(Session["dontdothis"]));
                   // if (Convert.ToBoolean(Session["dontdothis"]) == false)
                        // use this to fill textboxes
                        fillSpecificUser(userid);

                }
            }
            
        }
        private void fillUsers()
        {

            User myUser = new User();
           

            DataSet myDataSet = myUser.getAllUsers();

            // fill our dropdown
            ddlUsers.DataSource = myDataSet.Tables[0];
            ddlUsers.DataTextField = "FullName";
            ddlUsers.DataValueField = "userid";
            ddlUsers.DataBind();
          // add a choice
            ddlUsers.Items.Insert(0,new ListItem("-- choose --","-1"));

            Session["dontdothis"] = false;
        }

        private void fillSpecificUser(int userid)
        {


            /// fix this so that it uses the getdata with parameters
            /// ..... you can do it!
            /// I believe in you.
            string connection = ConfigurationManager.ConnectionStrings["ConnectionString"].ToString();

            // variable for database connection
            SqlConnection myConnection;

            myConnection = new SqlConnection(connection);
            // open a connection to the database
            myConnection.Open();

            string query = "SELECT FirstName, LastName, UserEmail, HiddenKey, userid FROM Paige_Login WHERE userid = " + userid; // one should feel itchy here..

            DataSet myDataSet = new DataSet();
            SqlCommand myCommand = new SqlCommand(query);
            myCommand.Connection = myConnection;
            myCommand.CommandType = CommandType.Text;

            SqlDataAdapter myAdapter = new SqlDataAdapter(myCommand);
            myAdapter.Fill(myDataSet);

            // what is this?
            myConnection.Close();

            txtFirstName.Text = myDataSet.Tables[0].Rows[0]["FirstName"].ToString();
            txtLastName.Text = myDataSet.Tables[0].Rows[0]["LastName"].ToString();
            txtUserEmail.Text = myDataSet.Tables[0].Rows[0]["UserEmail"].ToString();
            txtHiddenKey.Text = myDataSet.Tables[0].Rows[0]["HiddenKey"].ToString();

           // Session["dontdothis"] = true;
        }

        //update stuff
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            // retrieve first name from textbox
            string FirstName = txtFirstName.Text;

            // retrieve last name from textbox
            string LastName = txtLastName.Text;

            string UserEmail = txtUserEmail.Text;

            string HiddenKey = txtHiddenKey.Text;

            int ourTableID = Convert.ToInt32(Session["userid"]);
            // insert...
            User myUser = new User();
            myUser.PaigeUpdateUser(FirstName, LastName, UserEmail, userid); //do I need userid here?
            
            fillUsers();

            Response.Write("Update Successful!");
            resetStuff();

            // Server.Transfer("admin.aspx");

        }

        // insert button
        protected void Button1_Click(object sender, EventArgs e)
        {
            // retrieve first name from textbox
            string FirstName = txtFirstName.Text;

            // retrieve last name from textbox
            string LastName = txtLastName.Text;
            string UserEmail = txtUserEmail.Text;
            string HiddenKey = txtHiddenKey.Text;

            User myUser = new User();
            myUser.PaigeInsertUser(); //Do I need to insert 

            fillUsers();

            // do something here.. to remove the contents of our textboxes
            Response.Write("Insert Successful!");
            resetStuff();
        }

        protected void DeleteButton_Click(object sender, EventArgs e)
        {

            /// change this so that it uses the executenonquerywithparameters -- you can do this too! -- I still believe in you.
            // retrieve first name from textbox
            string FirstName = txtFirstName.Text;

            // retrieve the rest of the information
            string LastName = txtLastName.Text;
            string UserEmail = txtUserEmail.Text;
            string HiddenKey = txtHiddenKey.Text;

            User myUser = new User();
            myUser.PaigeDeleteUser(); 

            fillUsers();

            // do something here.. to remove the contents of our textboxes
            Response.Write("Delete Successful!");
            resetStuff();

            //int userid = Convert.ToInt32(Session[userid]);
            // delete...
            //string connection = ConfigurationManager.ConnectionStrings["ConnectionString"].ToString();
            //string query = "DELETE FROM Paige_Login " +
              //   " WHERE userid = " + userid;
            //Response.Write(query);

            // variable for database connection
           // SqlConnection myConnection;
            //myConnection = new SqlConnection(connection);
            // open a connection to the database
            //myConnection.Open();
            //SqlCommand myCommand = new SqlCommand(query);
            //myCommand.Connection = myConnection;
            //myCommand.CommandType = CommandType.Text;
            //myCommand.ExecuteNonQuery();
            // what is this?
            //myConnection.Close();
            //  Session["dontdothis"] = false;

            //fillUsers();
            Response.Write("Delete Successful!");
            resetStuff();
        }

        private void resetStuff()
        {
    
            txtFirstName.Text = "";
            txtLastName.Text = "";
            txtUserEmail.Text = "";
            txtHiddenKey.Text = "";
            Session["userid"] = null;
        }
    }
}