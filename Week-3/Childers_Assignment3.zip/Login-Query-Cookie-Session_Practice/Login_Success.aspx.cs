﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Login_Query_Cookie_Session_Practice
{
    public partial class Login_Success : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //QueryString
            string txtUsername = Request.QueryString["txtUsername"];
            //Response.Write(txtUsername);

            //Cookie
            //get cookie out
            HttpCookie myCookie = Request.Cookies["HiddenKey_cook"];
            string HiddenKey = myCookie.Value;


            //Session
            string Phone = Session["Phone"].ToString();


            //Response.Write(txtUsername + ":" + Key + Phone);
            Response.Write(txtUsername + Phone);


        }
    }
}