﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Login_Query_Cookie_Session_Practice
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            //QueryString
            string txtUsername = txtUser.Text;
            

            //retrieve password from textbox
            //Cookie
            string HiddenKey = txtHiddenKey.Text;

            //create a cookie object
            HttpCookie keyP = new HttpCookie("HiddenKey_cook");
            //add the value to the cookie
            keyP.Value = txtHiddenKey.Text;
            //cookie ends
            keyP.Expires.Add(new TimeSpan(0, 1, 0));
            //add the cookie to the cookies
            Response.Cookies.Add(keyP);

            //display password
            string hiddenCharacter = string.Empty;
            hiddenCharacter = Request.Cookies["keyP"].Value;



            //create a session
            //string Phone = txtPhoneNumber.Text;
            //Session.Add("Phone", Phone);

            //string based off of online info
            Session["Phone"] = txtPhoneNumber.Text;

            if (Session["Phone"] != null)
            {
                txtPhoneNumber.Text = Session["Phone"].ToString();
            }

            Response.Redirect("Login_Success.aspx/?txtUsername=" + txtUsername);
            Response.Write("HI" + txtUsername + keyP);
            //Response.Write("HI" + txtUsername + keyP);
        }
    }
}