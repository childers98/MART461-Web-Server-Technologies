﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Login_Query_Cookie_Session_Practice
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            //QueryString
            string txtUsername = txtUser.Text;
            Response.Redirect("Login_Success.aspx/?txtUsername=" + txtUsername);

            //retrieve password from textbox

            //Cookie
            //////string Key = txtHiddenKey.Text;

            //create a cookie object
            HttpCookie myCookie = new HttpCookie("Key_cook");
            //add the value to the cookie
            myCookie.Value = txtHiddenKey.Text;
            //add the cookie to the cookies
            Response.Cookies.Add(myCookie);


            //create a session
            //string Phone = txtPhoneNumber.Text;
            //Session.Add("Phone", Phone);
        }
    }
}