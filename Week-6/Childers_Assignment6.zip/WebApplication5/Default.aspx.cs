﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


//Might need to add these if they aren't already in the top
//using System.Configuration;
//using System.Data;
//using System.Data.SqlClient;

namespace WebApplication5 //WebApplication5 might need to be changed
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!Page.IsPostBack)
            {
                Response.Write("HI");
                showTable();

            }


        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {

          //  Response.Write("In button click");

            // retrieve email from textbox
            string UserEmail = txtUserEmail.Text;

            // retrieve password from textbox
            string HiddenKey = txtHiddenKey.Text;

            //retrieve FirstName from textbox
            string FirstName = txtFirstName.Text;

            // insert...
            string connection = ConfigurationManager.ConnectionStrings["ConnectionString"].ToString();

            string query = "INSERT INTO Paige_Login (Email, HiddenKey, FirstName) " +
                "VALUES ('" + UserEmail + "', '" + HiddenKey + "','" + FirstName + "');";

            // variable for database connection
            SqlConnection myConnection;

            myConnection = new SqlConnection(connection);
            // open a connection to the database
            myConnection.Open();

            SqlCommand myCommand = new SqlCommand(query);
            myCommand.Connection = myConnection;
            myCommand.CommandType = CommandType.Text;

            myCommand.ExecuteNonQuery();

            //close the query
            myConnection.Close();

            showTable();
        }

        private void showTable()
        {
            // always called first
            // Response.Write("HI in page load");

            // connection string, server name, username, password - here too
            string connection = ConfigurationManager.ConnectionStrings["ConnectionString"].ToString();

            // variable for database connection
            SqlConnection myConnection;

            myConnection = new SqlConnection(connection);
            // open a connection to the database
            myConnection.Open();

            string query = "SELECT * FROM Paige_Login"; 

            DataSet myDataSet = new DataSet();
            SqlCommand myCommand = new SqlCommand(query);
            myCommand.Connection = myConnection;
            myCommand.CommandType = CommandType.Text;

            SqlDataAdapter myAdapter = new SqlDataAdapter(myCommand);
            myAdapter.Fill(myDataSet);

            // closing the connection to the database
            myConnection.Close();

            //what does this need to be changed to? I know we spoke about this in class...
            gvUsers.DataSource = myDataSet.Tables[0];
            //make sure data actually shows
            gvUsers.DataBind();
        }
    }


}