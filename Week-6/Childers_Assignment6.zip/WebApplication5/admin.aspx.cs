﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

//may need to change namespace at times
namespace WebApplication5

{
    public partial class admin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
            
           
            if(!Page.IsPostBack)
            {
                fillUsers();
            }
            else
            {
                int paigeLogins = Convert.ToInt32(ddlUsers.SelectedValue);
                Session["Paige_Login"] = paigeLogins;

                if(Convert.ToBoolean(Session["dontdothis"]) == false)
                    fillSpecificUser(paigeLogins);
            }
            
        }
        private void fillUsers()
        {
            string connection = ConfigurationManager.ConnectionStrings["ConnectionString"].ToString();

            // variable for database connection
            SqlConnection myConnection;

            myConnection = new SqlConnection(connection);
            // open a connection to the database
            myConnection.Open();

            //changed this line
            string query = "SELECT UserEmail + ' ' + HiddenKey + ' ' + FirstName, userid FROM Paige_Login"; // one should feel itchy here..

            DataSet myDataSet = new DataSet();
            SqlCommand myCommand = new SqlCommand(query);
            myCommand.Connection = myConnection;
            myCommand.CommandType = CommandType.Text;

            SqlDataAdapter myAdapter = new SqlDataAdapter(myCommand);
            myAdapter.Fill(myDataSet);

            // what is this?
            myConnection.Close();

            // fill our dropdown
            ddlUsers.DataSource = myDataSet.Tables[0];
            ddlUsers.DataTextField = "FullName";
            ddlUsers.DataValueField = "userid";
            ddlUsers.DataBind();
        }

        private void fillSpecificUser(int paigeLogins)
        {
            string connection = ConfigurationManager.ConnectionStrings["ConnectionString"].ToString();

            // variable for database connection
            SqlConnection myConnection;

            myConnection = new SqlConnection(connection);
            // open a connection to the database
            myConnection.Open();

            string query = "SELECT Email, HiddenKey, FirstName, userid FROM Paige_Login WHERE userid = " + userid; // one should feel itchy here..

            DataSet myDataSet = new DataSet();
            SqlCommand myCommand = new SqlCommand(query);
            myCommand.Connection = myConnection;
            myCommand.CommandType = CommandType.Text;

            SqlDataAdapter myAdapter = new SqlDataAdapter(myCommand);
            myAdapter.Fill(myDataSet);

            //close connection - I believe to Database??
            myConnection.Close();

            txtUserEmail.Text = myDataSet.Tables[0].Rows[0]["UserEmail"].ToString();
            txtHiddenKey.Text = myDataSet.Tables[0].Rows[0]["HiddenKey"].ToString();
            txtFirstName.Text = myDataSet.Tables[0].Rows[0]["FirstName"].ToString();

            Session["dontdothis"] = true;
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            // retrieve email from textbox
            string UserEmail = txtUserEmail.Text;

            // retrieve last name from textbox
            string HiddenKey = txtHiddenKey.Text;

            string courseName = txtFirstName.Text;

            //what does this int need to be called?
            int paigeLogin = Convert.ToInt32(Session["paigeLogin"]);
            // insert...
            string connection = ConfigurationManager.ConnectionStrings["ConnectionString"].ToString();

            //UPDATE
            //string query = "UPDATE Paige_Login SET UserEmail='" + UserEmail +
            //    "',HiddenKey='" + HiddenKey + "',FirstName='" + FirstName + "'" +
            //    " WHERE userid = " + userid;
            //Response.Write(query);

            //attempt at an UPDATE #2 - the other one looks like it would actually work
            //  string query = "UPDATE Paige_Login (UserEmail, HiddenKey, FirstName) " +
            //    "VALUES ('" + UserEmail + "', '" + HiddenKey + "', '" + FirstName + "');";

            //INSERT
            string query = "INSERT INTO Paige_Login (UserEmail, HiddenKey, FirstName) " +
                "VALUES ('" + UserEmail + "', '" + HiddenKey + "', '" + FirstName + "');";

            //DELETE
            string query = "DELETE Paige_Login SET UserEmail='" + UserEmail +
               "',HiddenKey='" + HiddenKey + "',FirstName='" + FirstName + "'" +
                " WHERE userid = " + userid;



            // variable for database connection
            SqlConnection myConnection;

            myConnection = new SqlConnection(connection);
            // open a connection to the database
            myConnection.Open();

            SqlCommand myCommand = new SqlCommand(query);
            myCommand.Connection = myConnection;
            myCommand.CommandType = CommandType.Text;

            myCommand.ExecuteNonQuery();

            // what is this?
            myConnection.Close();
            Session["dontdothis"] = false;
            fillUsers();

        }
    }
}